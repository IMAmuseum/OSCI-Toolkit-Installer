OsciTk = {};
OsciTk.collections = {};
OsciTk.models = {};
OsciTk.templates = {};
OsciTk.views = {
	figureTypeRegistry: {}
};